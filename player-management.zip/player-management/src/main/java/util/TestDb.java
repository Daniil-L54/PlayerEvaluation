package util;

public class TestDb {
    public static void main(String[] args) {
        try {
            System.out.println(DBUtil.getConnection());
            System.out.println("CONNECT OK");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
