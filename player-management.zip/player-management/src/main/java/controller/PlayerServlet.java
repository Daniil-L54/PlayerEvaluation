package controller;

import dao.PlayerDAO;
import model.Player;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import java.io.IOException;
import java.util.List;

@WebServlet("/player")
public class PlayerServlet extends HttpServlet {

    private PlayerDAO dao = new PlayerDAO();

    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");

        try {
            if ("delete".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                dao.delete(id);
                resp.sendRedirect("player");
                return;
            }

            if ("edit".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                Player p = dao.findById(id);
                req.setAttribute("player", p);
                req.getRequestDispatcher("/edit.jsp").forward(req, resp);
                return;
            }

            List<Player> list = dao.findAll();
            req.setAttribute("players", list);
            req.getRequestDispatcher("/player.jsp").forward(req, resp);

        } catch (Exception e) {
            resp.getWriter().println("ERROR: " + e.getMessage());
        }
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String id = req.getParameter("id");
        String name = req.getParameter("name");
        String fullName = req.getParameter("fullName");
        String age = req.getParameter("age");
        int indexId = Integer.parseInt(req.getParameter("indexId"));

        if (name.isEmpty() || fullName.isEmpty() || !age.matches("\\d+")) {
            req.setAttribute("error", "Invalid data");
            req.getRequestDispatcher("/player.jsp").forward(req, resp);
            return;
        }

        try {
            Player p = new Player();
            p.setName(name);
            p.setFullName(fullName);
            p.setAge(age);
            p.setIndexId(indexId);

            if (id == null || id.isEmpty()) {
                dao.insert(p);
            } else {
                p.setPlayerId(Integer.parseInt(id));
                dao.update(p);
            }
            resp.sendRedirect("player");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
